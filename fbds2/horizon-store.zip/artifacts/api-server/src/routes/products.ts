import { Router, type IRouter } from "express";
import { eq, ilike, and, type SQL } from "drizzle-orm";
import { db, productsTable } from "@workspace/db";
import {
  ListProductsQueryParams,
  ListProductsResponse,
  CreateProductBody,
  GetProductParams,
  GetProductResponse,
  UpdateProductParams,
  UpdateProductBody,
  UpdateProductResponse,
  DeleteProductParams,
  GetFeaturedProductsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/products", async (req, res): Promise<void> => {
  const query = ListProductsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const { category, search, inStock } = query.data;
  const conditions: SQL[] = [];

  if (category) {
    conditions.push(eq(productsTable.category, category));
  }
  if (search) {
    conditions.push(ilike(productsTable.name, `%${search}%`));
  }
  if (inStock === true) {
    // handled post-query for simplicity with drizzle
  }

  const rows = await db
    .select()
    .from(productsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(productsTable.createdAt);

  const filtered = inStock === true ? rows.filter((r) => Number(r.stock) > 0) : rows;

  res.json(
    ListProductsResponse.parse(
      filtered.map((r) => ({
        ...r,
        price: Number(r.price),
        sizes: (r.sizes as string[]) ?? [],
        badge: r.badge ?? null,
        createdAt: r.createdAt.toISOString(),
      }))
    )
  );
});

router.get("/products/featured", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.featured, true))
    .orderBy(productsTable.createdAt);

  res.json(
    GetFeaturedProductsResponse.parse(
      rows.map((r) => ({
        ...r,
        price: Number(r.price),
        sizes: (r.sizes as string[]) ?? [],
        badge: r.badge ?? null,
        createdAt: r.createdAt.toISOString(),
      }))
    )
  );
});

router.get("/products/:id", async (req, res): Promise<void> => {
  const params = GetProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [row] = await db.select().from(productsTable).where(eq(productsTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.json(
    GetProductResponse.parse({
      ...row,
      price: Number(row.price),
      sizes: (row.sizes as string[]) ?? [],
      badge: row.badge ?? null,
      createdAt: row.createdAt.toISOString(),
    })
  );
});

router.post("/products", async (req, res): Promise<void> => {
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { price, ...rest } = parsed.data;
  const [row] = await db
    .insert(productsTable)
    .values({ ...rest, price: String(price) })
    .returning();

  res.status(201).json(
    GetProductResponse.parse({
      ...row,
      price: Number(row.price),
      sizes: (row.sizes as string[]) ?? [],
      badge: row.badge ?? null,
      createdAt: row.createdAt.toISOString(),
    })
  );
});

router.patch("/products/:id", async (req, res): Promise<void> => {
  const params = UpdateProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { price, ...rest } = parsed.data;
  const updateData: Record<string, unknown> = { ...rest };
  if (price !== undefined) updateData.price = String(price);

  const [row] = await db
    .update(productsTable)
    .set(updateData)
    .where(eq(productsTable.id, params.data.id))
    .returning();

  if (!row) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.json(
    UpdateProductResponse.parse({
      ...row,
      price: Number(row.price),
      sizes: (row.sizes as string[]) ?? [],
      badge: row.badge ?? null,
      createdAt: row.createdAt.toISOString(),
    })
  );
});

router.delete("/products/:id", async (req, res): Promise<void> => {
  const params = DeleteProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [row] = await db.delete(productsTable).where(eq(productsTable.id, params.data.id)).returning();

  if (!row) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
