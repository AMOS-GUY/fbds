import { useState } from "react";
import { motion } from "framer-motion";
import { pageVariants, pageTransition } from "@/lib/animations";
import { useCart } from "@/hooks/use-cart";
import { useCreateOrder } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Trash2, Plus, Minus, CheckCircle2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export default function Cart() {
  const { items, subtotal, updateQuantity, removeItem, clearCart } = useCart();
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const createOrder = useCreateOrder();

  const [destination, setDestination] = useState("Kigali");
  const [customerName, setCustomerName] = useState(user?.firstName ? `${user.firstName} ${user.lastName}` : "");
  const [customerPhone, setCustomerPhone] = useState(user?.phone || "");
  const [customerEmail, setCustomerEmail] = useState(user?.email || "");
  const [notes, setNotes] = useState("");
  const [orderComplete, setOrderComplete] = useState<any>(null);
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  const shippingCost = destination === "Kigali" ? 0 : 5000;
  const finalTotal = subtotal + shippingCost;

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;
    
    setIsSubmitting(true);

    const orderInput = {
      customerName,
      customerPhone,
      customerEmail,
      destination,
      items: items,
      subtotal,
      finalTotal,
      notes
    };

    createOrder.mutate({ data: orderInput }, {
      onSuccess: (order) => {
        setOrderComplete(order);
        clearCart();
        
        // Format WhatsApp message
        let waMessage = `*New Order: ${order.orderId}*\n\n`;
        waMessage += `*Customer:* ${customerName}\n`;
        waMessage += `*Phone:* ${customerPhone}\n`;
        waMessage += `*Destination:* ${destination}\n\n`;
        waMessage += `*Items:*\n`;
        items.forEach(i => {
          waMessage += `- ${i.quantity}x ${i.productName} (${i.size}) @ ${i.unitPrice} CFA\n`;
        });
        waMessage += `\n*Total:* ${finalTotal.toLocaleString()} CFA\n`;
        if (notes) waMessage += `\n*Notes:* ${notes}\n`;

        const encodedMsg = encodeURIComponent(waMessage);
        const waLink = `https://wa.me/22667030730?text=${encodedMsg}`;
        
        window.open(waLink, '_blank');
        setIsSubmitting(false);
      },
      onError: () => {
        toast({
          title: "Error",
          description: "Failed to create order. Please try again.",
          variant: "destructive"
        });
        setIsSubmitting(false);
      }
    });
  };

  if (orderComplete) {
    return (
      <motion.div
        initial="initial"
        animate="in"
        exit="out"
        variants={pageVariants}
        transition={pageTransition}
        className="container mx-auto px-4 py-24 text-center max-w-lg"
      >
        <CheckCircle2 className="w-20 h-20 text-green-500 mx-auto mb-6" />
        <h1 className="text-3xl font-serif font-bold mb-4">Order Confirmed!</h1>
        <p className="text-muted-foreground mb-2">Thank you for your purchase, {customerName}.</p>
        <p className="font-medium text-lg mb-8">Order ID: {orderComplete.orderId}</p>
        <div className="bg-muted p-6 rounded-lg mb-8 text-left">
          <p className="text-sm text-muted-foreground mb-4">
            We've opened WhatsApp to finalize your order. If it didn't open automatically, please contact us at +22667030730 with your Order ID.
          </p>
        </div>
        <div className="flex gap-4 justify-center">
          <Link href="/products">
            <Button variant="outline">Continue Shopping</Button>
          </Link>
          <Link href="/track-order">
            <Button>Track Order</Button>
          </Link>
        </div>
      </motion.div>
    );
  }

  if (items.length === 0) {
    return (
      <motion.div
        initial="initial"
        animate="in"
        exit="out"
        variants={pageVariants}
        transition={pageTransition}
        className="container mx-auto px-4 py-24 text-center max-w-lg"
      >
        <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-muted-foreground"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
        </div>
        <h1 className="text-3xl font-serif font-bold mb-4">Your cart is empty</h1>
        <p className="text-muted-foreground mb-8">Looks like you haven't added anything to your cart yet.</p>
        <Link href="/products">
          <Button size="lg" className="w-full sm:w-auto">Start Shopping</Button>
        </Link>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={pageTransition}
      className="container mx-auto px-4 py-12"
    >
      <h1 className="text-3xl font-serif font-bold mb-8">Shopping Cart</h1>

      <div className="grid lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-6">
          {items.map((item) => (
            <div key={`${item.productId}-${item.size}`} className="flex gap-6 border-b pb-6">
              <div className="w-24 h-32 bg-muted rounded-md overflow-hidden flex-shrink-0">
                <img src={item.image} alt={item.productName} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 flex flex-col justify-between">
                <div className="flex justify-between">
                  <div>
                    <h3 className="font-medium text-lg"><Link href={`/products/${item.productId}`} className="hover:underline">{item.productName}</Link></h3>
                    <p className="text-muted-foreground text-sm mt-1">Size: {item.size}</p>
                  </div>
                  <p className="font-medium">{item.unitPrice.toLocaleString()} CFA</p>
                </div>
                
                <div className="flex justify-between items-center mt-4">
                  <div className="flex items-center border rounded-md">
                    <Button variant="ghost" size="icon" className="h-9 w-9 rounded-none" onClick={() => updateQuantity(item.productId, item.size, item.quantity - 1)}>
                      <Minus className="w-3 h-3" />
                    </Button>
                    <span className="w-10 text-center text-sm">{item.quantity}</span>
                    <Button variant="ghost" size="icon" className="h-9 w-9 rounded-none" onClick={() => updateQuantity(item.productId, item.size, item.quantity + 1)}>
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive" onClick={() => removeItem(item.productId, item.size)}>
                    <Trash2 className="w-4 h-4 mr-2" /> Remove
                  </Button>
                </div>
              </div>
            </div>
          ))}
          
          <div className="pt-4">
            <Link href="/products" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4 mr-2" /> Continue Shopping
            </Link>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-muted/50 p-6 rounded-xl space-y-6 sticky top-24">
            <h2 className="text-xl font-serif font-bold">Order Summary</h2>
            
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>{subtotal.toLocaleString()} CFA</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span>{shippingCost === 0 ? "Free" : `${shippingCost.toLocaleString()} CFA`}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-serif text-xl font-bold pt-2">
                <span>Total</span>
                <span>{finalTotal.toLocaleString()} CFA</span>
              </div>
            </div>

            <form onSubmit={handleCheckout} className="space-y-4 pt-4 border-t">
              <h3 className="font-medium">Checkout Details</h3>
              
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" value={customerName} onChange={e => setCustomerName(e.target.value)} required />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number (WhatsApp)</Label>
                <Input id="phone" type="tel" value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} required />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="destination">Destination</Label>
                <Select value={destination} onValueChange={setDestination}>
                  <SelectTrigger id="destination">
                    <SelectValue placeholder="Select destination" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Kigali">Kigali (Free)</SelectItem>
                    <SelectItem value="Other Provinces">Other Provinces (5,000 CFA)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Order Notes (Optional)</Label>
                <Textarea id="notes" value={notes} onChange={e => setNotes(e.target.value)} rows={2} />
              </div>
              
              <Button type="submit" className="w-full h-12 text-lg mt-4" disabled={isSubmitting}>
                {isSubmitting ? "Processing..." : "Checkout via WhatsApp"}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
